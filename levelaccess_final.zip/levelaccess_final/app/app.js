angular.module('myApp', [
    'ngRoute',
    'myApp.home',
    'ui.grid',
    'ui.grid.edit',
    'ui.grid.exporter'
])
    .config(['$routeProvider', function($routeProvider) {
    // Set defualt view of our app to home

    $routeProvider.otherwise({
        redirectTo: '/home'
    });
}]);