angular.module('myApp.home', ['ngRoute'])

// Declared route 
    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/home', {
            templateUrl: 'home/home.html',
            controller: 'HomeCtrl'
        });
    }])

    // Home controller
    .controller('HomeCtrl', ['$http','$scope','$timeout','uiGridConstants','$route', function($http,$scope,$timeout,uiGridConstants,$route) {
        $scope.name = "";
        $scope.parentid = "";
        $scope.description = "";
        $scope.gridview = true;
        $scope.addview = false;
        $scope.editview = false;


        $scope.itemid_edit = "";
        $scope.name_edit = "";
        $scope.pid_edit = "";
        $scope.description_edit = "";


        var baseUrl = 'http://localhost:3000';
        /*$http({
            method: 'GET',
            url: 'https://levelaccessdb.firebaseio.com/item.json'
        }).then(function (response) {
            var data = response.data;
            $scope.myData = []
            var i =1;
            angular.forEach(data, function(value, key){

                value.item_id = i;
                $scope.myData.push(value);
                i=i+1;
            });

        });
*/ $scope.gridOptions = {
            exporterMenuCsv: false,
            enableGridMenu: true,
            showGridFooter: true,

            columnDefs: [
                { name: 'item_id' },
                { name: 'name'},
                { name: 'parent_id' },
                { name:'description'},
                { name:'key',displayName:'Actions',
                    cellTemplate:
                        '<div style="align-content: center">&nbsp;&nbsp;'+
                        '<button class="btn btn-warning" ng-click="grid.appScope.editItem(row.entity.key,row.entity.item_id,row.entity.name,row.entity.parent_id,row.entity.description)">Edit</button>&nbsp;&nbsp;&nbsp;'+
                        '<button class="btn btn-danger" ng-click="grid.appScope.deleteItem(row.entity.key)">Delete</button>'+
                        '</div>'
                }

            ],
            gridMenuCustomItems: [
                {
                    title: 'Rotate Grid',
                    action: function ($event) {
                        this.grid.element.toggleClass('rotated');
                    },
                    order: 210
                }
            ],
            onRegisterApi: function( gridApi ){
                $scope.gridApi = gridApi;


                gridApi.core.on.columnVisibilityChanged( $scope, function( changedColumn ){
                    $scope.columnChanged = { name: changedColumn.colDef.name, visible: changedColumn.colDef.visible };
                });
            }
        };



        $http({
            method: 'GET',
            url: 'https://levelaccessdb.firebaseio.com/item.json'
        }).then(function (response) {
            var data = response.data;
            $scope.myData = []
            var i =1;
            angular.forEach(data, function(value, key){
                if(key!== null){
                    value.key = key;
                    value.item_id = i;
                    $scope.myData.push(value);
                }

                i=i+1;
            });
            $scope.gridOptions.data = $scope.myData;


        });

        $scope.myFunction = function() {
            $scope.count++;
        }


        $scope.addItem = function() {
            var itemid = $scope.myData.length + 1;
            var newitemobj = {item_id:itemid, parent_id:$scope.parentid,name:$scope.name,description:$scope.description};

            //  $http.post('http://localhost:3000/item',newitemobj );

            $http.post("https://levelaccessdb.firebaseio.com/item.json", newitemobj, {
                headers:  'Content-Type: application/json'
            });

            $scope.myData.push(newitemobj);
            swal({
                title: "Sweet!",
                text: "New item Added ."
            });

        };


        $scope.additemview = function () {
            $scope.gridview = false;
            $scope.addview = true ;
        };

        $scope.itemslist = function () {
            $scope.gridview = true;
            $scope.addview = false ;
        };

        $scope.clear = function () {
            $scope.name = "";
            $scope.parentid = "";
            $scope.description = "";
        };

        $scope.clearedit = function () {
            $scope.name_edit = "";
            $scope.pid_edit = "";
            $scope.description_edit = "";
        };




        $scope.editItem = function (key,item_id,name,pid,description) {
            $scope.key_edit = key;
            $scope.editview = true;
            $scope.itemid_edit = item_id;
            $scope.name_edit = name;
            $scope.pid_edit = pid;
            $scope.description_edit = description;

        };



        $scope.submitedit = function () {
            $scope.url_edit = "https://levelaccessdb.firebaseio.com/item/"+$scope.key_edit+".json";

            var edititemobj = {item_id:$scope.itemid_edit, parent_id:$scope.pid_edit,name:$scope.name_edit,description:$scope.description_edit};

            //  $http.post('http://localhost:3000/item',newitemobj );

            $http.put($scope.url_edit, edititemobj, {
                headers:  'Content-Type: application/json'
            });
            swal({
                title: "Sweet!",
                text: "item ID "+$scope.itemid_edit +" Edited ."
            });

            $route.reload();
        };



        $scope.deleteItem = function(key) {
            $scope.url = "https://levelaccessdb.firebaseio.com/item/"+key+".json";

            // call DELETE http method
            $http.delete($scope.url).success(function(data) {
                swal({
                    title: "Deleted!",
                    text: "In order to see the change reload the Page",
                    type: "warning"
                });
            }).error(function(err) {
                console.log("delete error : "+err);
            });
        };



    }]);